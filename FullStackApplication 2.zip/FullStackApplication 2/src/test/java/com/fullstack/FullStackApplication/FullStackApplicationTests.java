package com.fullstack.FullStackApplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FullStackApplicationTests {

	@Test
	void contextLoads() {
	}

}
