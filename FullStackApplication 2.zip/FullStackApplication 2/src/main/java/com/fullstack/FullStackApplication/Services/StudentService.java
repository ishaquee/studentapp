package com.fullstack.FullStackApplication.Services;

import com.fullstack.FullStackApplication.Model.Student;
import com.fullstack.FullStackApplication.repositery.StudentRepositery;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class StudentService implements  StudentSericeImp {

    @Autowired
    private StudentRepositery studentRepositery;

    @Override
    public Student saveStudent(Student student) {
        return studentRepositery.save(student);
    }

    @Override
    public List<Student> getAllStudents() {
        return studentRepositery.findAll();
    }
}
