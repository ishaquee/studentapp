package com.fullstack.FullStackApplication.Controller;

import com.fullstack.FullStackApplication.Model.Student;
import com.fullstack.FullStackApplication.Services.StudentSericeImp;
import com.fullstack.FullStackApplication.Services.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/student")
public class StudentController {

    @Autowired
    private StudentSericeImp sericeImp;

    @CrossOrigin(origins = "http://localhost:3000")
    @PostMapping("/add")
    public Student add(@RequestBody Student student){
        return sericeImp.saveStudent(student);
    }

    @CrossOrigin(origins = "http://localhost:3000")
    @GetMapping("/getall")
    public List <Student>getAllStudents()
    {
        return sericeImp.getAllStudents();
    }
}
