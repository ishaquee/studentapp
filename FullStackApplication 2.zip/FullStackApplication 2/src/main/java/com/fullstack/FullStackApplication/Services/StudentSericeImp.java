package com.fullstack.FullStackApplication.Services;

import com.fullstack.FullStackApplication.Model.Student;

import java.util.List;

public interface StudentSericeImp {
    public Student saveStudent(Student student);
    public List<Student> getAllStudents();

}
